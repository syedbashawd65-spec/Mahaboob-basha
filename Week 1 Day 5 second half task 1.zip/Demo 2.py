import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

os.makedirs("reports/figures", exist_ok=True)



sns.set_style("whitegrid")

PRIMARY = "#1f77b4"
SECONDARY = "#ff7f0e"
ACCENT = "#2ca02c"
FOURTH = "#d62728"
FIFTH = "#9467bd"



np.random.seed(42)

rows = 200

months = pd.date_range(
    start="2024-01-01",
    periods=12,
    freq="ME"
)

df = pd.DataFrame({
    "Month": np.random.choice(months, rows),
    "Category": np.random.choice(
        ["Electronics", "Furniture", "Clothing"],
        rows
    ),
    "Sales": np.random.randint(500, 5000, rows),
    "Profit": np.random.randint(50, 1200, rows),
    "Age": np.random.randint(18, 65, rows),
    "Advertising_Spend": np.random.randint(
        100,
        5000,
        rows
    )
})



print("\nFIRST 5 ROWS")
print(df.head())

print("\nDATA TYPES")
print(df.dtypes)

print("\nSHAPE")
print(df.shape)



bar_data = (
    df.groupby("Category")["Sales"]
    .mean()
    .sort_values(ascending=False)
)

plt.figure(figsize=(8,5))

bar_data.plot(
    kind="bar",
    color=PRIMARY
)

plt.title("Average Sales by Category")
plt.xlabel("Category")
plt.ylabel("Average Sales ($)")

plt.tight_layout()

plt.savefig(
    "reports/figures/bar_chart.png",
    dpi=300,
    bbox_inches="tight"
)

plt.show()

print(
    "Insight: Categories show different average sales performance."
)



plt.figure(figsize=(8,5))

plt.hist(
    df["Age"],
    bins=10,
    color=SECONDARY,
    edgecolor="black",
    label="Age Distribution"
)

plt.title("Customer Age Distribution")
plt.xlabel("Age (Years)")
plt.ylabel("Frequency")
plt.legend()

plt.tight_layout()

plt.savefig(
    "reports/figures/histogram.png",
    dpi=300,
    bbox_inches="tight"
)

plt.show()

print(
    "Insight: Most customers cluster around the middle age groups."
)



plt.figure(figsize=(8,5))

plt.scatter(
    df["Advertising_Spend"],
    df["Sales"],
    color=ACCENT,
    alpha=0.7,
    label="Customers"
)

plt.title("Advertising Spend vs Sales")
plt.xlabel("Advertising Spend ($)")
plt.ylabel("Sales ($)")
plt.legend()

plt.tight_layout()

plt.savefig(
    "reports/figures/scatter_plot.png",
    dpi=300,
    bbox_inches="tight"
)

plt.show()

print(
    "Insight: Higher advertising spend generally leads to higher sales."
)



monthly_sales = (
    df.groupby(
        df["Month"].dt.to_period("M")
    )["Sales"]
    .mean()
)

plt.figure(figsize=(10,5))

plt.plot(
    monthly_sales.index.astype(str),
    monthly_sales.values,
    marker="o",
    color=FOURTH,
    linewidth=2,
    label="Average Sales"
)

plt.title("Monthly Average Sales Trend")
plt.xlabel("Month")
plt.ylabel("Average Sales ($)")
plt.xticks(rotation=45)
plt.legend()

plt.tight_layout()

plt.savefig(
    "reports/figures/line_chart.png",
    dpi=300,
    bbox_inches="tight"
)

plt.show()

print(
    "Insight: Sales fluctuate throughout the year."
)


plt.figure(figsize=(8,6))

corr_matrix = (
    df.select_dtypes(include="number")
    .corr()
)

sns.heatmap(
    corr_matrix,
    annot=True,
    cmap="Blues",
    fmt=".2f"
)

plt.title("Correlation Heatmap")

plt.tight_layout()

plt.savefig(
    "reports/figures/heatmap.png",
    dpi=300,
    bbox_inches="tight"
)

plt.show()

print(
    "Insight: The heatmap shows relationships among numerical variables."
)



print("\nAll visualizations created successfully.")
print("Figures saved in: reports/figures/")